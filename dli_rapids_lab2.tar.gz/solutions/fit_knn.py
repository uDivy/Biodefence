road_locs = road_nodes[['east', 'north']]
knn.fit(road_locs)
