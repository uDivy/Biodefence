dask_knn.fit(ddf[['northing', 'easting']])
