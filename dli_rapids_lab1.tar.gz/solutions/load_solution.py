print('If you can see this you loaded this code correctly. Now try running it.')
