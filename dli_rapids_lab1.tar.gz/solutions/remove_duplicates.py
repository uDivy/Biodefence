road_nodes = road_nodes.drop_duplicates().reset_index(drop=True)
road_edges = road_edges.drop_duplicates().reset_index(drop=True)
