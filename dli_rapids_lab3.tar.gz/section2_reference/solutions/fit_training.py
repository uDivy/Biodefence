logreg = cuml.LogisticRegression()
logreg.fit(X_train, y_train)
