logreg.fit(gdf[['age', 'sex']], gdf['infected'])
