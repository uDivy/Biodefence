knn = cuml.NearestNeighbors(n_neighbors=3)
