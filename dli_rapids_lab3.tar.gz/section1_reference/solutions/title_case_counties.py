gdf['county'] = gdf['county'].str.title()
