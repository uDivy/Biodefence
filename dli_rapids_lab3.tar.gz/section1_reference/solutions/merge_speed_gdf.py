road_edges = road_edges.merge(speed_gdf, on='type')
road_edges.dtypes
